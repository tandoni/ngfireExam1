export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAEokswfPD2aEviw0lkVIy-urAykhb2i_g",
    authDomain: "tandoni-install-test2.firebaseapp.com",
    databaseURL: "https://tandoni-install-test2.firebaseio.com",
    projectId: "tandoni-install-test2",
    storageBucket: "",
    messagingSenderId: "350956948026"
  },
};
